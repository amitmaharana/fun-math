export class User {
    userid: number;
    name: string;
    password: string;
    role: number;
  }