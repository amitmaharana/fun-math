export class Assignment {
    id: number;
    name: string;
    dueDate: Date;
    createdDate: Date;
    marks: number;
  }