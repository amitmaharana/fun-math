import { User } from './user';

export const Users: User[] = [
    { userid: 11, name: 'Asmi', password: 'Asmi', role: 0 },
    { userid: 12, name: 'Dhananjay', password: 'Dhananjay', role: 0 },
    { userid: 13, name: 'Sharad', password: 'Sharad', role: 0 },
    { userid: 14, name: 'Naren', password: 'Naren', role: 0 },
    { userid: 15, name: 'Satyen', password: 'Satyen', role: 0 }
];